setwd("C:\\Users\\LENOVO\\OneDrive\\Desktop\\IT24102731")

# 1.

Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)

fix(Delivery_Times)

# 2.

breaks_seq <- seq(20, 70, length.out = 10)

hist(Delivery_Times$Delivery_Time_.minutes.,
     breaks = breaks_seq,
     right = FALSE,              
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Frequency")


# 3.

# The distribution of delivery times is approximately symmetric and bell-shaped, 
# resembling a normal distribution with most values centered around 40 minutes.


# 4.

hist_obj <- hist(Delivery_Times$Delivery_Time_.minutes.,
                 breaks = breaks_seq,
                 right = FALSE,
                 plot = FALSE)

cum_freq <- cumsum(hist_obj$counts)

plot(hist_obj$breaks[-1], cum_freq, type = "o",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency",
     col = "red", pch = 16)

