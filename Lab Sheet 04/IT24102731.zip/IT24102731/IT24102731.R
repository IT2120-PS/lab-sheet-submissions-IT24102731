setwd("C:\\Users\\IT24102731\\Desktop\\IT24102731")
getwd()

# 1.
branch_data<-read.table("Exercise.txt",header = TRUE,sep = ",")

# 2.
str(branch_data)

# 3.
boxplot(branch_data$Sales_X1,main="Boxplot of Sales",outline=TRUE,outpch=8,horizontal=TRUE)

# 4.
summary(branch_data$Advertising_X2) 
fivenum(branch_data$Advertising_X2) 
IQR(branch_data$Advertising_X2)      

# 5. 
find_outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3 - q1
  
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  outliers <- x[x < lb | x > ub]
  return(outliers)
}

find_outliers(branch_data$Years_X3)
